import SwiftUI
import Combine
import AVFoundation
import CoreML
import WhisperKit

import ScreenCaptureKit
import CoreMedia
import Accelerate
import CoreGraphics


// MARK: - Tabs
//enum CommandTab: Hashable {
//    case listen
//    case ask
//    case settings
//}

struct OverlayRootView: View {

    @ObservedObject private var overlay = OverlayModel.shared
    @EnvironmentObject private var auth: AuthState
    @State private var autoScroll = true
    @State private var isExpanded = false
    @State private var selectedTab: CommandTab = .listen
    @Namespace private var islandNS
    @State private var question: String = ""
    @State private var smartMode: Bool = false
    @FocusState private var askFocused: Bool
    @ObservedObject private var hint = HintAgent.shared
    @State private var showTranscript = true
    @State private var showResponse: Bool = false
    @State private var lastNonSettingsTab: CommandTab = .listen
    // MARK: - Tabs


    // наш безопасный ленивый транскрайбер
    @StateObject private var transcriptionCoordinator = TranscriptionCoordinator()

    // NEW: вью-модель для снапшота/отправки
    @StateObject private var askVM: AskVM
    @ObservedObject private var oauthCoordinator = OAuthCoordinator.shared

    init(auth: AuthState) {
        _askVM = StateObject(wrappedValue: AskVM(auth: auth))
        OAuthCoordinator.shared.configure(authState: auth)
    }

    private var systemChannelState: OverlayModel.TranscriptionChannelState {
        overlay.transcriptionState(for: .system)
    }

    private var microphoneChannelState: OverlayModel.TranscriptionChannelState {
        overlay.transcriptionState(for: .microphone)
    }

    var body: some View {
        Group {
            if auth.isAuthorized {
                authorizedOverlay
            } else {
                ApiKeyGateView()
                    .environmentObject(oauthCoordinator)
            }
        }
    }
    
    private var settingsPanel: some View {
        SettingsSheet(isShown: settingsShownBinding)
            .environmentObject(auth)
            .padding(.horizontal, 8)
            .environmentObject(overlay)
    }

    private var authorizedOverlay: some View {
        overlayIsland
    }

    private var overlayIsland: some View {
        VStack(spacing: 14) {
            FloatingToolbar(
                isRecording: overlay.anyChannelIsTranscribing,
                selected: $selectedTab,
                onPrimaryTap: { isExpanded = true },
                onEyeTap: {
                    OverlayWindowManager.shared.withResizeSuspended(0.86, finalAnimate: true)
                    withAnimation(.spring(response: 0.2, dampingFraction: 0.86)) {
                        isExpanded.toggle()
                    }
                },
                onMenuTap: {
                    OverlayWindowManager.shared.withResizeSuspended(0.2, finalAnimate: true)
                    withAnimation(.spring(response: 0.2, dampingFraction: 0.86)) {
                        if selectedTab == .settings {
                            selectedTab = lastNonSettingsTab
                        } else {
                            lastNonSettingsTab = selectedTab
                            selectedTab = .settings
                            isExpanded = true
                        }
                    }
                }
            )
            .padding(.top, 8)

            // ⬇️ ГЛАВНОЕ: если открыт Settings — показываем его вместо остальных панелей
            if isExpanded {
                Group {
                    switch selectedTab {
                    case .listen:    listenPanel
                    case .ask:       askPanel
                    case .settings:  settingsPanel
                    }
                }
                .padding(.horizontal, 8)
                .matchedGeometryEffect(id: "island", in: islandNS)
                .transition(.move(edge: .top).combined(with: .opacity))
                .zIndex(1)
            }
        }
        // окно подстраивается по высоте как и для других панелей
        .overlayAutoResize()
        .animation(.spring(response: 0.2, dampingFraction: 0.86), value: isExpanded)
        .animation(.spring(response: 0.2, dampingFraction: 0.86), value: selectedTab)
        .onChange(of: overlay.askSolveTrigger) { _ in
            isExpanded = true
            selectedTab = .ask
            question = ""
            askFocused = true

            let transcriptTail = makeTranscriptTail(seconds: 40, maxChars: 900)
            Task { await askVM.submitWithoutQuery(transcript: transcriptTail) }

            OverlayWindowManager.shared.scheduleResize(animate: false)
            OverlayWindowManager.shared.kickFinalResize(after: 0.2)
        }
        .onChange(of: isExpanded) { _ in
            if isExpanded && selectedTab == .ask { askFocused = true }
            OverlayWindowManager.shared.scheduleResize(animate: false)
            OverlayWindowManager.shared.kickFinalResize(after: 0.2)
        }
        .onChange(of: selectedTab) { tab in
            if isExpanded && tab == .ask { askFocused = true }
            OverlayWindowManager.shared.scheduleResize(animate: false)
            OverlayWindowManager.shared.kickFinalResize(after: 0.2)
        }

        .onChange(of: showTranscript) { _ in
            OverlayWindowManager.shared.scheduleResize(animate: false)
            OverlayWindowManager.shared.kickFinalResize(after: 0.2)
        }
        .onAppear {
            OverlayWindowManager.shared.scheduleResize(animate: false)
            OverlayWindowManager.shared.kickFinalResize(after: 0.2)
        }
    }

    // MARK: - Listen Panel

    private var listenPanel: some View {
        GlassCard {
            VStack(alignment: .leading, spacing: 10) {

                // HEADER (компактный)
                HStack(spacing: 12) {
                    LogoOrb().frame(width: 18, height: 18)

                    VStack(alignment: .leading, spacing: 2) {
                        Text(showTranscript ? "Транскрипт" : "Инсайты в реальном времени")
                            .font(.headline.weight(.semibold))
                        HStack(spacing: 6) {
                            LiveDot(active: overlay.anyChannelIsTranscribing)
                            let isOn = overlay.anyChannelIsTranscribing

                            Text(isOn ? "Идёт запись…" : "Готов к запуску")
                                .font(.caption2.monospaced())
                                .foregroundStyle(isOn ? .green : .secondary)
                                .glow(active: isOn, color: .green) // мягкое свечение только когда запись идёт
                                .animation(.easeInOut(duration: 0.25), value: isOn)
                        }
                    }

                    Spacer(minLength: 8)

                    Button(showTranscript ? "Инсайты" : "Транскрипт") {
                        withAnimation(.spring(response: 0.28, dampingFraction: 0.9)) {
                            showTranscript.toggle()
                        }
                        OverlayWindowManager.shared.scheduleResize(animate: false)
                        OverlayWindowManager.shared.kickFinalResize(after: 0.30)
                    }
                    .buttonStyle(GlassPill())

                    let phase = transcriptionCoordinator.overallPhase
                    let running  = phase == .running
                    let starting = phase == .starting
                    let stopping = phase == .stopping

                    Button {
                        switch phase {
                        case .idle: transcriptionCoordinator.startRecording()
                        case .starting, .running, .stopping: transcriptionCoordinator.stopAll()
                        }
                    } label: {
                        HStack(spacing: 6) {
                            if starting || stopping { ProgressView().controlSize(.small) }
                            Image(systemName: (running || stopping) ? "stop.fill" : "play.fill")
                            Text(starting ? "Запуск…" : (stopping ? "Остановка…" : (running ? "Стоп" : "Старт")))
                        }
                    }
                    .buttonStyle(GlassPill(tint: (running || stopping) ? .red : .accentColor))
                    .disabled(starting)

                    Button {
                        transcriptionCoordinator.setMicrophoneArmed(!transcriptionCoordinator.isMicrophoneArmed)
                    } label: {
                        Label("Микрофон", systemImage: transcriptionCoordinator.isMicrophoneArmed ? "mic.fill" : "mic")
                    }
                    .buttonStyle(GlassPill(tint: transcriptionCoordinator.isMicrophoneArmed ? .pink : .secondary))
                }
                .padding(.vertical, 2)

                // --------- ВАЖНО: дальше — тело панели ---------
                Divider().overlay(Color.white.opacity(0.10))

                if showTranscript {
                    TranscriptChatView(
                        systemState: systemChannelState,
                        microphoneState: microphoneChannelState,
                        autoScroll: $autoScroll
                    )
                    .transition(.opacity.combined(with: .move(edge: .top)))
                    .edgeFade(height: 320)     // фикс высоты + плавное затухание краёв

                    HintStrip()
                        .padding(.top, 6)
                } else {
                    InsightsPanel(
                        hint: hint,
                        onRequest: { intent in requestInsight(intent) },
                        onClose: {
                            withAnimation(.spring(response: 0.28, dampingFraction: 0.9)) {
                                showTranscript = true
                            }
                        }
                    )
                    .transition(.opacity.combined(with: .move(edge: .top)))
                    .frame(height: 420)        // чтобы окно не «скакало», держим такую же высоту
                }
            }
        }
        .frame(maxWidth: 600)
        .padding(.horizontal, 8)
    }
    
    
    
    private var settingsShownBinding: Binding<Bool> {
        Binding(
            get: { selectedTab == .settings },
            set: { show in
                if show {
                    if selectedTab != .settings { lastNonSettingsTab = selectedTab }
                    selectedTab = .settings
                } else {
                    selectedTab = lastNonSettingsTab
                }
            }
        )
    }

    private struct TranscriptChatView: View {
        let systemState: OverlayModel.TranscriptionChannelState
        let microphoneState: OverlayModel.TranscriptionChannelState
        @Binding var autoScroll: Bool

        @State private var hasAppeared = false

        // Автоскроллим только если экран уже появился и авто-скролл включён
        private var shouldAutoScroll: Bool { hasAppeared && autoScroll }

        // Объединённая лента
        private var mergedMessages: [OverlayModel.TranscriptMessage] {
            (systemState.transcriptLog + microphoneState.transcriptLog)
                .sorted { lhs, rhs in
                    if lhs.timestamp == rhs.timestamp {
                        return lhs.id.uuidString < rhs.id.uuidString
                    }
                    return lhs.timestamp < rhs.timestamp
                }
        }

        // Группировка подряд идущих сообщений по source (system / microphone)
        private struct MessageGroup: Identifiable {
            let source: OverlayModel.AudioSourceKind
            var items: [OverlayModel.TranscriptMessage]
            var id: UUID { items.first?.id ?? UUID() } // стабильный id по первой реплике
        }

        private func grouped(_ messages: [OverlayModel.TranscriptMessage]) -> [MessageGroup] {
            var result: [MessageGroup] = []
            for m in messages {
                if let i = result.indices.last, result[i].source == m.source {
                    result[i].items.append(m)
                } else {
                    result.append(MessageGroup(source: m.source, items: [m]))
                }
            }
            return result
        }

        private func partialText(for kind: OverlayModel.AudioSourceKind) -> String? {
            let text: String = (kind == .system) ? systemState.partialText : microphoneState.partialText
            return text.isEmpty ? nil : text
        }

        private func partialIdentifier(_ kind: OverlayModel.AudioSourceKind) -> String {
            "partial_\(kind.rawValue)"
        }

        private var lastAnchorID: AnyHashable? {
            if let micPartial = partialText(for: .microphone) {
                return AnyHashable(partialIdentifier(.microphone) + micPartial)
            }
            if let sysPartial = partialText(for: .system) {
                return AnyHashable(partialIdentifier(.system) + sysPartial)
            }
            return mergedMessages.last?.id
        }

        var body: some View {
            VStack(alignment: .leading, spacing: 12) {
                ScrollViewReader { proxy in
                    ZStack {
                        let shape = RoundedRectangle(cornerRadius: 16, style: .continuous)

                        shape
                            .fill(Color.white.opacity(0.03))
                            .overlay(shape.stroke(Color.white.opacity(0), lineWidth: 0))

                        ScrollView {
                            LazyVStack(spacing: 8) {
                                ForEach(grouped(mergedMessages)) { group in
                                    let style = TranscriptSourceStyle.for(kind: group.source)

                                    // первая в группе — с «шапкой»
                                    if let first = group.items.first {
                                        TranscriptMessageBubble(
                                            message: first,
                                            style: style,
                                            showHeader: true
                                        )
                                        .id(first.id)
                                    }

                                    // остальные — без «шапки»
                                    ForEach(group.items.dropFirst()) { msg in
                                        TranscriptMessageBubble(
                                            message: msg,
                                            style: style,
                                            showHeader: false
                                        )
                                        .id(msg.id)
                                    }
                                }

                                if let text = partialText(for: .system) {
                                    PartialTranscriptBubble(text: text, style: .for(kind: .system))
                                        .id(partialIdentifier(.system) + text)
                                }

                                if let text = partialText(for: .microphone) {
                                    PartialTranscriptBubble(text: text, style: .for(kind: .microphone))
                                        .id(partialIdentifier(.microphone) + text)
                                }
                            }
                            .padding(.vertical, 12)
                            .padding(.horizontal, 12)
                        }
                        .clipShape(shape)
                    }
                    // ВАЖНО: без minHeight — высоту контролирует родитель через .edgeFade(height:)
                    .onAppear {
                        hasAppeared = true
                        DispatchQueue.main.async { scrollToBottom(proxy, animated: false) }
                    }
                    .onChange(of: systemState.transcriptLog.last?.id) { _ in
                        if shouldAutoScroll { scrollToBottom(proxy) }
                    }
                    .onChange(of: microphoneState.transcriptLog.last?.id) { _ in
                        if shouldAutoScroll { scrollToBottom(proxy) }
                    }
                    .onChange(of: systemState.partialText) { _ in
                        if shouldAutoScroll { scrollToBottom(proxy) }
                    }
                    .onChange(of: microphoneState.partialText) { _ in
                        if shouldAutoScroll { scrollToBottom(proxy) }
                    }
                    .onChange(of: autoScroll) { enabled in
                        if enabled && hasAppeared { scrollToBottom(proxy, animated: false) }
                    }
                    // Любой drag по ленте — ставим паузу автоскролла
                    .gesture(DragGesture().onChanged { _ in
                        if autoScroll { autoScroll = false }
                    })
                    // Кнопка «В конец», если автоскролл выключен
                    .overlay(alignment: .bottomTrailing) {
                        if !autoScroll {
                            Button {
                                autoScroll = true
                                scrollToBottom(proxy)
                            } label: {
                                Label("В конец", systemImage: "arrow.down.circle.fill")
                                    .font(.caption.weight(.semibold))
                            }
                            .buttonStyle(GlassPill(tint: .secondary))
                            .padding(8)
                        }
                    }
                }
            }
            .frame(maxWidth: .infinity, alignment: .topLeading)
        }

        private func scrollToBottom(_ proxy: ScrollViewProxy, animated: Bool = true) {
            guard let anchor = lastAnchorID else { return }
            let action = { proxy.scrollTo(anchor, anchor: .bottom) }
            if animated {
                withAnimation(.easeOut(duration: 0.22)) { action() }
            } else {
                action()
            }
        }
    }

    private struct TranscriptMessageBubble: View {
        let message: OverlayModel.TranscriptMessage
        let style: TranscriptSourceStyle
        var showHeader: Bool = true   // ← новое

        var body: some View {
            VStack(alignment: .leading, spacing: showHeader ? 6 : 4) {
                if showHeader {
                    HStack(spacing: 6) {
                        Image(systemName: style.icon)
                            .font(.caption.weight(.semibold))
                            .foregroundStyle(style.color.opacity(0.85))
                        Text(style.title)
                            .font(.caption2.weight(.semibold))
                            .foregroundStyle(style.color.opacity(0.85))
                        Spacer(minLength: 0)
                    }
                }

                Text(message.text)
                    .font(.system(size: 13)) // чуть компактнее
                    .foregroundStyle(.primary)
                    .textSelection(.enabled)
                    .multilineTextAlignment(.leading)
                    .fixedSize(horizontal: false, vertical: true)

                // Таймстамп можно показывать только у первой в группе (чтоб не шумел)
                if showHeader {
                    Text(message.timestamp, style: .time)
                        .font(.caption2)
                        .foregroundStyle(style.color.opacity(0.8))
                }
            }
            .padding(.vertical, showHeader ? 10 : 6)
            .padding(.horizontal, 12)
            .frame(maxWidth: 320, alignment: .leading)
            .background(
                RoundedRectangle(cornerRadius: 14, style: .continuous)
                    .fill(style.color.opacity(0.14))
                    .overlay(
                        RoundedRectangle(cornerRadius: 14, style: .continuous)
                            .stroke(style.color.opacity(0.18), lineWidth: 1)
                    )
            )
            .frame(maxWidth: .infinity, alignment: style.bubbleAlignment)
            .transition(.move(edge: .trailing).combined(with: .opacity))
        }
    }

    private struct PartialTranscriptBubble: View {
        let text: String
        let style: TranscriptSourceStyle

        var body: some View {
            HStack(alignment: .firstTextBaseline, spacing: 6) {
                Image(systemName: "ellipsis")
                    .font(.caption.weight(.semibold))
                    .foregroundStyle(style.color.opacity(0.8))
                Text(text)
                    .italic()
                    .foregroundStyle(.secondary)
            }
            .padding(.vertical, 9)
            .padding(.horizontal, 12)
            .frame(maxWidth: 240, alignment: .leading)
            .background(
                RoundedRectangle(cornerRadius: 12, style: .continuous)
                    .fill(style.color.opacity(0.10))
            )
            .frame(maxWidth: .infinity, alignment: style.bubbleAlignment)
        }
    }

    private struct TranscriptStatusBadge: View {
        let kind: OverlayModel.AudioSourceKind
        let state: OverlayModel.TranscriptionChannelState

        private var style: TranscriptSourceStyle { .for(kind: kind) }

        var body: some View {
            HStack(spacing: 10) {
                ZStack {
                    Circle()
                        .fill(style.color.opacity(0.18))
                        .frame(width: 30, height: 30)
                    Image(systemName: style.icon)
                        .font(.system(size: 15, weight: .semibold))
                        .foregroundStyle(style.color)
                }

                VStack(alignment: .leading, spacing: 2) {
                    Text(style.title)
                        .font(.caption.weight(.semibold))
                        .foregroundStyle(.primary)
                    Text(style.caption)
                        .font(.caption2)
                        .foregroundStyle(.secondary)
                }

                Spacer(minLength: 4)

                VStack(alignment: .trailing, spacing: 4) {
                    LiveDot(active: state.isTranscribing)
                    Text(state.isTranscribing ? "Активно" : "Ожидание")
                        .font(.caption2)
                        .foregroundStyle(state.isTranscribing ? style.color : .secondary)
                }
            }
            .padding(.vertical, 10)
            .padding(.horizontal, 12)
            .background(
                RoundedRectangle(cornerRadius: 14, style: .continuous)
                    .fill(Color.white.opacity(0.04))
                    .overlay(
                        RoundedRectangle(cornerRadius: 14, style: .continuous)
                            .stroke(Color.white.opacity(0.08), lineWidth: 1)
                    )
            )
            .frame(maxWidth: .infinity, alignment: style.bubbleAlignment)
        }
    }

    private struct TranscriptSourceStyle {
        let icon: String
        let color: Color
        let caption: String
        let title: String
        let bubbleAlignment: Alignment

        static func `for`(kind: OverlayModel.AudioSourceKind) -> TranscriptSourceStyle {
            switch kind {
            case .system:
                return TranscriptSourceStyle(
                    icon: "waveform.circle.fill",
                    color: .cyan,
                    caption: "Системный поток",
                    title: kind.title,
                    bubbleAlignment: .leading
                )
            case .microphone:
                return TranscriptSourceStyle(
                    icon: "mic.circle.fill",
                    color: .pink,
                    caption: "Микрофон",
                    title: kind.title,
                    bubbleAlignment: .trailing
                )
            }
        }
    }

    // MARK: - Ask Panel

    private var askPanel: some View {
        VStack(spacing: 12) {
            AskBar(
                text: $question,
                isSubmitting: askVM.isSubmitting,
                onSubmit: submitQuestion
            )
            .frame(maxWidth: 600)

            if showResponse {
                AIResponseCard(
                    title: "AI Response",
                    query: question,
                    markdown: askVM.answerDraft.isEmpty ? "Генерация ответа…" : askVM.answerDraft,
                    isStreaming: askVM.isSubmitting,
                    canStop: askVM.canStop,
                    onCopy: {
                        #if os(macOS)
                        NSPasteboard.general.clearContents()
                        NSPasteboard.general.setString(askVM.answerDraft, forType: .string)
                        #endif
                    },
                    onClose: {
                        askVM.cancelStream()
                        askVM.answerDraft = ""
                        askVM.answerError = nil
                        withAnimation(.spring(response: 0.28, dampingFraction: 0.9)) { showResponse = false }
                    },
                    onStop: { askVM.cancelStream() }
                )
                .frame(maxWidth: 600, minHeight: 220)
                .transition(.move(edge: .top).combined(with: .opacity))
            }
        }
        .onChange(of: askVM.isSubmitting) { v in
            if v { withAnimation(.spring(response: 0.28, dampingFraction: 0.9)) { showResponse = true } }
        }
        .onChange(of: askVM.answerDraft) { v in
            if !v.isEmpty { showResponse = true }
        }
        .frame(maxWidth: 600)  // Фиксируем максимальную ширину всей панели

        .padding(.horizontal, 8)
    }

    // MARK: - Header (не используется в текущем лэйауте, оставлен как заготовка)

    private var header: some View {
        HStack(spacing: 12) {
            LogoOrb()

            VStack(alignment: .leading, spacing: 2) {
                PhotonText("Распознавание системного звука")
                    .font(.headline)

                HStack(spacing: 8) {
                    LiveDot(active: overlay.anyChannelIsTranscribing)
                    Text(overlay.anyChannelIsTranscribing ? "Идёт запись…" : "Готов к запуску")
                        .font(.system(.caption, design: .monospaced))
                        .foregroundStyle(overlay.anyChannelIsTranscribing ? .green.opacity(0.9) : .secondary)
                }
            }

            Spacer()

            HStack(spacing: 10) {
                let microphonePhase = microphoneChannelState.phase
                let microphoneBusy = microphonePhase == .starting || microphonePhase == .stopping

                Button {
                    transcriptionCoordinator.setMicrophoneArmed(!transcriptionCoordinator.isMicrophoneArmed)
                } label: {
                    Label("Микрофон", systemImage: transcriptionCoordinator.isMicrophoneArmed ? "mic.fill" : "mic")
                }
                .buttonStyle(GlassPill(tint: transcriptionCoordinator.isMicrophoneArmed ? .pink : .secondary))
                .disabled(microphoneBusy)

                Button {
                    switch transcriptionCoordinator.overallPhase {
                    case .idle:
                        transcriptionCoordinator.startRecording()
                    case .starting, .running, .stopping:
                        transcriptionCoordinator.stopAll()
                    }
                } label: {
                    let phase = transcriptionCoordinator.overallPhase
                    let running  = phase == .running
                    let starting = phase == .starting
                    let stopping = phase == .stopping
                    Label(
                        starting ? "Запуск…" : (stopping ? "Остановка…" : (running ? "Стоп" : "Старт")),
                        systemImage: (running || stopping) ? "stop.fill" : "play.fill"
                    )
                }
                .buttonStyle(
                    GlassPill(
                        tint: {
                            let phase = transcriptionCoordinator.overallPhase
                            return (phase == .running || phase == .stopping) ? .red : .accentColor
                        }()
                    )
                )
                .disabled(transcriptionCoordinator.overallPhase == .starting)
            }
        }
    }

    // MARK: - Footer

    private var footer: some View {
        HStack(spacing: 12) {
            Toggle(isOn: $autoScroll) { Text("Автопрокрутка") }
                .toggleStyle(.switch)
                .tint(.accentColor)

            Spacer()

            Button {
                transcriptionCoordinator.clearLogs(for: .system)
            } label: {
                Label("Очистить", systemImage: "trash")
            }
            .buttonStyle(GlassPill(tint: .secondary))
            .disabled(systemChannelState.transcriptLog.isEmpty && systemChannelState.partialText.isEmpty)
        }
        .padding(.top, 2)
    }

    // MARK: - Actions

    // NEW: Submit ВСЕГДА шлёт ВОПРОС + ХВОСТ ТРАНСКРИПТА + СКРИНШОТ
    private func submitQuestion() async {
        let tr = makeTranscriptTail(seconds: 40, maxChars: 900)

        await askVM.submit(
            question: question,
            smart: smartMode,
            transcript: tr
        )

        ServerClient.shared.log("question submitted: \(question), smart=\(smartMode), speechTail=\(tr.count) chars")
    }

    private func requestInsight(_ intent: HintAgent.Intent) {
        Task {
            await hint.requestHint(for: intent)
        }
    }

    // Хвост транскрибации
    private func makeTranscriptTail(seconds: Int = 40, maxChars: Int = 900) -> String {
        let bufferTail = TranscriptBuffer.shared.tail(lastSeconds: seconds, maxChars: maxChars)
        if !bufferTail.isEmpty {
            return bufferTail
        }
        return transcriptionCoordinator.transcriptTail(for: .system, maxChars: maxChars)
    }
}

// MARK: - Универсальная стеклянная карточка
//
//private struct GlassCard<Content: View>: View {
//    @ViewBuilder var content: () -> Content
//
//    var body: some View {
//        let shape = RoundedRectangle(cornerRadius: 16, style: .continuous)
//
//        ZStack {
//            Color.clear
//                .background(.ultraThinMaterial, in: shape)
//                .overlay(
//                    shape.stroke(
//                        LinearGradient(
//                            colors: [.white.opacity(0.45), .white.opacity(0.12)],
//                            startPoint: .topLeading, endPoint: .bottomTrailing
//                        ),
//                        lineWidth: 1
//                    )
//                )
//
//            VStack(spacing: 0) { content() }
//                .padding(12)
//        }
//        .clipShape(shape)
//        .contentShape(shape)
//        .fixedSize(horizontal: false, vertical: true) // ← самосжатие по высоте
//    }
//}

// MARK: - HintStrip (без изменений)

private struct HintStrip: View {
    @ObservedObject var hint: HintAgent = .shared
    @ObservedObject private var overlay = OverlayModel.shared

    private var iconName: String {
        (hint.activeIntent ?? hint.lastCompletedIntent)?.symbolName ?? "sparkles"
    }

    private var title: String {
        (hint.activeIntent ?? hint.lastCompletedIntent)?.stripTitle ?? "Подсказка"
    }

    private var placeholder: String? {
        if let active = hint.activeIntent { return active.placeholder }
        if let last = hint.lastCompletedIntent { return last.placeholder }
        return nil
    }

    var body: some View {
        if hint.isRunning || !hint.draft.isEmpty || hint.error != nil {
            VStack(alignment: .leading, spacing: 8) {
                HStack {
                    HStack(spacing: 6) {
                        Image(systemName: iconName)
                            .font(.callout.weight(.semibold))
                        Text(title)
                            .font(.headline)
                    }
                    .foregroundStyle(.primary)

                    if hint.isRunning { ProgressView().controlSize(.small) }
                    Spacer()
                    if hint.isRunning {
                        if let started = hint.startedAt {
                            HStack(spacing: 4) {
                                Text("Старт")
                                Text(started, style: .time)
                            }
                            .font(.caption2)
                            .foregroundStyle(.secondary)
                        } else {
                            Text("Генерация…")
                                .font(.caption2)
                                .foregroundStyle(.secondary)
                        }
                    } else if let finished = hint.lastFinishedAt {
                        HStack(spacing: 4) {
                            Text("Обновлено")
                            Text(finished, style: .time)
                        }
                        .font(.caption2)
                        .foregroundStyle(.secondary)
                    }

                    if hint.canStop {
                        Button("Стоп") { hint.cancel() }
                            .buttonStyle(GlassPill(tint: .red))
                    }
                }

                if let err = hint.error {
                    Text(err).foregroundStyle(.red).font(.subheadline)
                } else if !hint.draft.isEmpty {
                    Text(hint.draft)
                        .textSelection(.enabled)
                        .font(.body)
                        .fixedSize(horizontal: false, vertical: true)

                    HStack {
                        Button("Копировать") {
                            #if os(macOS)
                            NSPasteboard.general.clearContents()
                            NSPasteboard.general.setString(hint.draft, forType: .string)
                            #endif
                        }
                        .buttonStyle(GlassPill())
                        Spacer()
                        Button("Очистить") { hint.draft = "" }
                            .buttonStyle(GlassPill(tint: .secondary))
                    }
                } else if hint.isRunning {
                    Text("Ghost AI готовит подсказку…")
                        .font(.subheadline)
                        .foregroundStyle(.secondary)
                        .italic()
                } else if let placeholder {
                    Text(placeholder)
                        .font(.subheadline)
                        .foregroundStyle(.secondary)
                }
            }
            .padding(12)
            .background(
                Group {
                    if overlay.usesLiquidGlass, #available(macOS 26.0, *) {
                        RoundedRectangle(cornerRadius: 12, style: .continuous)
                            .fill(Color.clear)
                            .glassEffect(.clear, in: .rect(cornerRadius: 12))
                    } else {
                        RoundedRectangle(cornerRadius: 12, style: .continuous)
                            .fill(Color.white.opacity(0.06))
                            .overlay(
                                RoundedRectangle(cornerRadius: 12, style: .continuous)
                                    .stroke(.white.opacity(0.12), lineWidth: 1)
                            )
                    }
                }
            )
        }
    }
}

private struct AIResponseCard: View {
    var title: String
    var query: String
    var markdown: String
    var isStreaming: Bool
    var canStop: Bool
    var onCopy: () -> Void
    var onClose: () -> Void
    var onStop: () -> Void
    @ObservedObject private var overlay = OverlayModel.shared

    var body: some View {
        GlassCard {
            VStack(spacing: 0) {
                // Header
                HStack(spacing: 10) {
                    Label(title, systemImage: "sparkles")
                        .font(.headline.weight(.semibold))

                    Spacer()

                    if !query.isEmpty {
                        Text(query)
                            .font(.subheadline.weight(.semibold))
                            .lineLimit(1)
                            .padding(.horizontal, 10)
                            .padding(.vertical, 5)
                            .background(
                                Group {
                                    if overlay.usesLiquidGlass, #available(macOS 26.0, *) {
                                        Capsule()
                                            .fill(Color.clear)
                                            .glassEffect(.clear, in: .capsule)
                                    } else {
                                        Capsule().fill(Color.white.opacity(0.06))
                                            .overlay(Capsule().stroke(.white.opacity(0.12), lineWidth: 1))
                                    }
                                }
                            )
                    }

                    Button(action: onCopy) { Image(systemName: "doc.on.doc") }
                        .buttonStyle(MiniIconButton())

                    if canStop {
                        Button(action: onStop) { Image(systemName: "stop.fill") }
                            .buttonStyle(MiniIconButton())
                    }

                    Button(action: onClose) { Image(systemName: "xmark") }
                        .buttonStyle(MiniIconButton())
                }
                .padding(.bottom, 8)

                Divider().overlay(Color.white.opacity(0.10))

                // Body (Markdown)
                ScrollView {
                    let attr = (try? AttributedString(markdown: markdown)) ?? AttributedString(markdown)
                    Text(attr)
                        .textSelection(.enabled)
                        .frame(maxWidth: .infinity, alignment: .leading)
                        .padding(14)
                }
                .frame(minHeight: 180)
            }
            .padding(12)
        }
    }
}

import SwiftUI

private struct LegibilityScrim<S: Shape>: View {
    @Environment(\.colorScheme) private var scheme
    @Environment(\.accessibilityReduceTransparency) private var reduceTransparency

    let shape: S
    var intensity: Double = 0.35   // было 0.9 — из-за этого «белило»

    var body: some View {
        let base = (scheme == .dark ? Color.white : Color.black)
        let o1 = (reduceTransparency ? 0.12 : 0.08) * intensity
        let o2 = (reduceTransparency ? 0.08 : 0.05) * intensity

        return shape
            .fill(
                LinearGradient(
                    colors: [base.opacity(o1), base.opacity(o2)],
                    startPoint: .topLeading, endPoint: .bottomTrailing
                )
            )
            .blendMode(.softLight)
            .allowsHitTesting(false)
            .accessibilityHidden(true)
    }
}

private struct AskBar: View {
    @Binding var text: String
    var isSubmitting: Bool
    var onSubmit: () async -> Void

    @FocusState private var focused: Bool
    @ObservedObject private var overlay = OverlayModel.shared

    var body: some View {
        HStack(spacing: 12) {
            // блок с иконкой + TextField
            HStack(spacing: 10) {
                Image(systemName: "text.magnifyingglass")
                    .font(.system(size: 14, weight: .semibold))
                    .foregroundStyle(.secondary)

                TextField("Задай вопрос об экране или аудио", text: $text, axis: .vertical)
                    .lineLimit(1...3)
                    .textFieldStyle(.plain)
                    .focused($focused)
                    .onSubmit { Task { await onSubmit() } }
            }
            .padding(.horizontal, 14)
            .frame(height: 42)
            .background(
                Group {
                    if overlay.usesLiquidGlass, #available(macOS 26.0, *) {
                        Capsule()
                            .glassEffect(.clear, in: .capsule) // ← вернули стекло
                            .overlay(LegibilityScrim(shape: Capsule(), intensity: 0.35))
                    } else {
                        Capsule().fill(.ultraThinMaterial)
                    }
                }
            )

            Button(isSubmitting ? "Submitting…" : "Submit") {
                Task { await onSubmit() }
            }
            .keyboardShortcut(.return, modifiers: [])
            .buttonStyle(GlassPill())
            .disabled(isSubmitting)
        }
        .padding(8)
        .frame(height: 58)

        // Фон всего бара: ВСЕГДА RoundedRectangle(16) + те же эффекты, но под прямоугольник
        .background(
            Group {
                if overlay.usesLiquidGlass, #available(macOS 26.0, *) {
                    let rr = RoundedRectangle(cornerRadius: 16, style: .continuous)

                    rr.fill(Color.clear)
                        .glassEffect(.clear, in: .rect(cornerRadius: 16))
                        .overlay(
                            rr.stroke(
                                LinearGradient(
                                    colors: [Color.white.opacity(0.35), Color.white.opacity(0.10)],
                                    startPoint: .topLeading, endPoint: .bottomTrailing
                                ),
                                lineWidth: 1
                            )
                            .blendMode(.screen)
                            .allowsHitTesting(false)
                        )
                        .overlay(
                            rr.inset(by: 1.5)
                                .stroke(Color.white.opacity(0.40), lineWidth: 0.6)
                                .blur(radius: 1.0)
                                .opacity(0.7)
                                .blendMode(.screen)
                                .allowsHitTesting(false)
                        )
                        .glassEffectTransition(.matchedGeometry)
                        .shadow(color: Color.black.opacity(0.12), radius: 12, y: 6)
                        .overlay(
                            rr.fill(
                                LinearGradient(
                                    colors: [Color.indigo.opacity(0.25), Color.purple.opacity(0.18)],
                                    startPoint: .topLeading, endPoint: .bottomTrailing
                                )
                            )
                            .blendMode(.softLight)
                            .opacity(0.02)
                            .allowsHitTesting(false)
                            .accessibilityHidden(true)
                        )
                } else {
                    RoundedRectangle(cornerRadius: 16, style: .continuous)
                        .fill(.ultraThinMaterial)
                        .overlay(
                            RoundedRectangle(cornerRadius: 16, style: .continuous)
                                .stroke(Color.black.opacity(0.08), lineWidth: 1)
                        )
                }
            }
        )
        .contentShape(RoundedRectangle(cornerRadius: 16, style: .continuous))
    }
}



private struct AskInputBar: View {
    @Binding var text: String
    @Binding var smart: Bool
    var isSubmitting: Bool
    var focus: FocusState<Bool>.Binding
    var onSubmit: () -> Void
    @ObservedObject private var overlay = OverlayModel.shared

    var body: some View {
        HStack(spacing: 10) {
            Button {
                smart.toggle()
            } label: {
                HStack(spacing: 6) {
                    Image(systemName: "bolt.fill")
                    Text("Smart")
                }
                .font(.system(size: 12, weight: .semibold))
                .padding(.horizontal, 10).padding(.vertical, 6)
                .background(
                    Group {
                        if overlay.usesLiquidGlass, #available(macOS 26.0, *) {
                            RoundedRectangle(cornerRadius: 16, style: .continuous)
                                .fill(Color.clear)
                                .glassEffect(.clear, in: .rect(cornerRadius: 16))
                        } else {
                            RoundedRectangle(cornerRadius: 16, style: .continuous)
                                .fill(.ultraThinMaterial)
                        }
                    }
                )
            }
            .buttonStyle(.plain)

            TextField("Ask about your screen or audio", text: $text)
                .focused(focus)
                .textFieldStyle(.plain)
                .font(.system(size: 16, weight: .medium))
                .padding(.horizontal, 14).padding(.vertical, 10)
                .background(
                    Group {
                        if overlay.usesLiquidGlass, #available(macOS 26.0, *) {
                            Capsule()
                                .fill(Color.clear)
                                .glassEffect(.clear, in: .capsule)
                        } else {
                            Capsule().fill(Color.white.opacity(0.06))
                                .overlay(Capsule().stroke(.white.opacity(0.10), lineWidth: 1))
                        }
                    }
                )
                .onSubmit { onSubmit() }
                .disableAutocorrection(true)

            Button(isSubmitting ? "Submitting…" : "Submit") {
                onSubmit()
            }
            .font(.system(size: 14, weight: .semibold))
            .padding(.horizontal, 14).padding(.vertical, 9)
            .background(
                Group {
                    if overlay.usesLiquidGlass, #available(macOS 26.0, *) {
                        Capsule()
                            .fill(Color.clear)
                            .glassEffect(.regular.tint(.accentColor).interactive(), in: .capsule)
                    } else {
                        Capsule().fill(Color.accentColor)
                            .overlay(Capsule().stroke(.white.opacity(0.20), lineWidth: 0.5))
                    }
                }
            )
            .foregroundStyle(.white)
            .disabled(isSubmitting)
            .keyboardShortcut(.return, modifiers: [.command])
        }
    }
}

private struct ResponseCard: View {
    var questionTitle: String
    var bodyText: String
    var isLoading: Bool
    var canStop: Bool
    var onCopy: () -> Void
    var onClose: () -> Void
    var onStop: () -> Void

    var body: some View {
        VStack(spacing: 8) {
            HStack(spacing: 10) {
                HStack(spacing: 8) {
                    Circle().fill(Color.white.opacity(0.15)).frame(width: 10, height: 10)
                    Text(questionTitle)
                        .font(.system(size: 14, weight: .semibold))
                }

                Spacer()

                Button(action: onCopy) {
                    Image(systemName: "doc.on.doc")
                }
                .buttonStyle(MiniIconButton())

                if canStop {
                    Button(action: onStop) {
                        Image(systemName: "xmark")
                    }
                    .buttonStyle(MiniIconButton())
                }

                Button(action: onClose) {
                    Image(systemName: "xmark.circle.fill")
                }
                .buttonStyle(MiniIconButton())
            }

            Divider().overlay(Color.white.opacity(0.08))

            ScrollView {
                Text(bodyText)
                    .textSelection(.enabled)
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .font(.system(size: 15))
                    .padding(.vertical, 4)
            }
            .frame(minHeight: 160, maxHeight: 420)
        }
        .padding(6)
    }
}

//private struct MiniIconButton: ButtonStyle {
//    func makeBody(configuration: Configuration) -> some View {
//        configuration.label
//            .font(.system(size: 12.5, weight: .semibold))
//            .frame(width: 28, height: 28)
//            .background(
//                RoundedRectangle(cornerRadius: 7, style: .continuous)
//                    .fill(.thinMaterial)
//                    .overlay(RoundedRectangle(cornerRadius: 7).stroke(.white.opacity(0.18), lineWidth: 0.75))
//            )
//            .scaleEffect(configuration.isPressed ? 0.96 : 1)
//    }
//}

// AskField
struct AskField: View {
    @Binding var text: String
    @Binding var smartEnabled: Bool
    var isSubmitting: Bool = false
    var onSubmit: () async -> Void
    var focused: FocusState<Bool>.Binding

    var body: some View {
        HStack(spacing: 10) {
            TextEditor(text: $text)
                .focused(focused)
                .font(.title3.weight(.medium))
                .frame(maxWidth: 600, minHeight: 80)  // Фиксируем ширину для TextEditor
                .padding(.vertical, 10)
                .padding(.leading, 12)
                .background(
                    RoundedRectangle(cornerRadius: 8)
                        .fill(Color(NSColor.textBackgroundColor))
                )

            HStack(spacing: 8) {
                Toggle(isOn: $smartEnabled) {
                    Label("Smart Mode", systemImage: "bolt")
                        .labelStyle(.titleAndIcon)
                        .font(.subheadline.weight(.semibold))
                }
                .toggleStyle(.button)
                .tint(.accentColor.opacity(0.7))

                Button(isSubmitting ? "Submitting…" : "Submit") {
                    Task { await onSubmit() }
                }
                .buttonStyle(GlassPill(tint: .accentColor))
                .disabled(isSubmitting)
            }
            .padding(.trailing, 8)
        }
        .frame(maxWidth: 600)  // Фиксируем максимальную ширину для всего поля ввода
        .padding(.horizontal, 6)
        .contentShape(Rectangle())
        .allowsHitTesting(true)
    }
}

// MARK: - GlassPill

struct GlassPill: ButtonStyle {
    var tint: Color? = nil
    @ObservedObject private var overlay = OverlayModel.shared
    func makeBody(configuration: Configuration) -> some View {
        Group {
            if overlay.usesLiquidGlass, #available(macOS 26.0, *) {
                let resolvedTint = tint ?? .accentColor
                configuration.label
                    .font(.system(size: 13, weight: .semibold))
                    .padding(.horizontal, 14)
                    .padding(.vertical, 8)
                    .glassEffect(
                        tint == nil ? .clear : .regular.tint(resolvedTint).interactive(),
                        in: .capsule
                    )
                    .tint(resolvedTint)
                    .scaleEffect(configuration.isPressed ? 0.98 : 1)
                    .animation(.spring(response: 0.28, dampingFraction: 0.9), value: configuration.isPressed)
            } else {
                configuration.label
                    .font(.system(size: 13, weight: .semibold))
                    .foregroundStyle(.primary)
                    .padding(.horizontal, 14)
                    .padding(.vertical, 8)
                    .background(
                        Capsule(style: .continuous)
                            .fill(.thinMaterial)
                            .overlay(Capsule().stroke(.white.opacity(0.2), lineWidth: 1))
                            .shadow(
                                color: (tint ?? .accentColor).opacity(configuration.isPressed ? 0.25 : 0.4),
                                radius: configuration.isPressed ? 6 : 12,
                                x: 0, y: 0
                            )
                    )
                    .scaleEffect(configuration.isPressed ? 0.98 : 1)
                    .animation(.spring(response: 0.28, dampingFraction: 0.9), value: configuration.isPressed)
            }
        }
    }
}

// ====== ВСПОМОГАТЕЛЬНЫЕ ШТУКИ (как были) ======

@MainActor
final class AskVM: ObservableObject {
    @Published var isSubmitting: Bool = false
    @Published var answerDraft: String = ""
    @Published var answerError: String? = nil
    @Published var canStop: Bool = false

    private var streamTask: Task<Void, Never>?
    private var streamRunID = UUID()
    private let baseURL = URL(string: "https://api.ghostai.ru")!
    private let sessionId = UUID().uuidString
    private let auth: AuthState
    private let serverClient: ServerClient

    init(auth: AuthState, serverClient: ServerClient = .shared) {
        self.auth = auth
        self.serverClient = serverClient
    }

    func cancelStream() {
        streamTask?.cancel()
        streamRunID = UUID()
        streamTask = nil
        canStop = false
        isSubmitting = false
    }

    func submit(
        question: String,
        smart: Bool,
        transcript: String
    ) async {
        let q = question.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !q.isEmpty else {
            NSLog("AskVM: skipped submit — empty question")
            return
        }

        await performSubmission(
            endpoint: "/ask",
            question: q,
            smart: smart,
            transcript: transcript
        )
    }

    func submitWithoutQuery(
        transcript: String,
        smart: Bool = true
    ) async {
        let trimmedTranscript = transcript.trimmingCharacters(in: .whitespacesAndNewlines)
        let fallbackQuestion = trimmedTranscript.isEmpty ? Self.fallbackAutoAskPrompt : nil

        if fallbackQuestion != nil {
            NSLog("AskVM: no transcript tail, using fallback auto-ask prompt")
        }

        await performSubmission(
            endpoint: "/ask_without_query",
            question: fallbackQuestion,
            smart: smart,
            transcript: trimmedTranscript
        )
    }

    private func performSubmission(
        endpoint: String,
        question: String?,
        smart: Bool,
        transcript: String
    ) async {
        guard let token = auth.currentKey, !token.isEmpty else {
            answerError = "Добавьте API-ключ, чтобы отправить вопрос."
            return
        }

        streamTask?.cancel()
        let runID = UUID()
        streamRunID = runID

        answerDraft = ""
        answerError = nil
        isSubmitting = true
        canStop = true
        NSLog("AskVM isSubmitting = true")
        defer {
            NSLog("AskVM isSubmitting = false")
            isSubmitting = false
            canStop = false
        }

        do {
            let png = try await Snapshot.captureAllDisplaysPNG(maxSide: 1280)

            try await sendToGPT(
                endpoint: endpoint,
                question: question,
                screenshotPNG: png,
                smart: smart,
                transcript: transcript,
                token: token
            )
        } catch {
            answerError = error.localizedDescription
            NSLog("AskVM submit failed: \(error.localizedDescription)")
        }
    }

    private func sendToGPT(
        endpoint: String,
        question: String?,
        screenshotPNG: Data,
        smart: Bool,
        transcript: String,
        token: String
    ) async throws {
        var req = URLRequest(url: baseURL.appendingPathComponent(endpoint))
        req.httpMethod = "POST"
        req.setValue("text/event-stream", forHTTPHeaderField: "Accept")
        serverClient.authorize(&req, token: token)

        let boundary = "----ghostai-\(UUID().uuidString)"
        req.setValue("multipart/form-data; boundary=\(boundary)", forHTTPHeaderField: "Content-Type")

        var body = Data()
        func appendField(_ name: String, _ value: String) {
            body.append("--\(boundary)\r\n".data(using: .utf8)!)
            body.append("Content-Disposition: form-data; name=\"\(name)\"\r\n\r\n".data(using: .utf8)!)
            body.append("\(value)\r\n".data(using: .utf8)!)
        }
        func appendFile(_ name: String, filename: String, mime: String, data: Data) {
            body.append("--\(boundary)\r\n".data(using: .utf8)!)
            body.append("Content-Disposition: form-data; name=\"\(name)\"; filename=\"\(filename)\"\r\n".data(using: .utf8)!)
            body.append("Content-Type: \(mime)\r\n\r\n".data(using: .utf8)!)
            body.append(data)
            body.append("\r\n".data(using: .utf8)!)
        }

        if let question {
            appendField("question", question)
        }
        appendField("smart", smart ? "true" : "false")
        appendField("sessionId", sessionId)

        let transcriptPayload = transcript.trimmingCharacters(in: .whitespacesAndNewlines)
        appendField("transcript", transcriptPayload)

        appendFile("image", filename: "screen.png", mime: "image/png", data: screenshotPNG)

        body.append("--\(boundary)--\r\n".data(using: .utf8)!)
        req.httpBody = body

        let (bytes, response) = try await URLSession.shared.bytes(for: req)
        guard let http = response as? HTTPURLResponse else { throw URLError(.badServerResponse) }

        if serverClient.handleUnauthorizedStatus(http.statusCode, auth: auth) {
            throw NSError(domain: "auth", code: http.statusCode,
                          userInfo: [NSLocalizedDescriptionKey: serverClient.unauthorizedMessage])
        }

        if !(200..<300).contains(http.statusCode) {
            var errText = "HTTP \(http.statusCode) \(HTTPURLResponse.localizedString(forStatusCode: http.statusCode))"
            var data = Data()
            do {
                for try await b in bytes { data.append(b) }
                if let s = String(data: data, encoding: .utf8), !s.isEmpty { errText += "\n\(s)" }
            } catch {}
            throw NSError(domain: "net", code: http.statusCode,
                          userInfo: [NSLocalizedDescriptionKey: errText])
        }

        var buffer = ""
        var lastFlush = Date()

        for try await line in bytes.lines {
            try Task.checkCancellation()
            guard line.hasPrefix("data: ") else { continue }

            let jsonStr = String(line.dropFirst(6))
            guard
                let data = jsonStr.data(using: .utf8),
                let obj = try? JSONSerialization.jsonObject(with: data) as? [String: Any],
                let type = obj["type"] as? String
            else { continue }

            if type == "delta", let text = obj["text"] as? String {
                buffer += text
                let shouldFlushByLen = buffer.count >= 64
                let shouldFlushByPunct = buffer.last.map { ".,!?;:\n ".contains($0) } ?? false
                let shouldFlushByTime = Date().timeIntervalSince(lastFlush) > 0.06
                if shouldFlushByLen || shouldFlushByPunct || shouldFlushByTime {
                    answerDraft += buffer
                    buffer.removeAll(keepingCapacity: true)
                    lastFlush = Date()
                }
            } else if type == "done" {
                if !buffer.isEmpty {
                    answerDraft += buffer
                    buffer.removeAll()
                }
                break
            } else if type == "error" {
                let msg = (obj["message"] as? String) ?? "Unknown error"
                throw NSError(domain: "sse", code: -1,
                              userInfo: [NSLocalizedDescriptionKey: msg])
            }
        }

        if !buffer.isEmpty { answerDraft += buffer }
    }
}

private extension AskVM {
    static let fallbackAutoAskPrompt = """
    Ты — Ghost AI-помощник. Пользователь нажал горячую клавишу без голосового контекста. Проанализируй приложенный скриншот, опиши, что на нём происходит, какие проблемы заметны и какие шаги стоит предпринять, чтобы их решить. Отвечай кратко и по делу.
    """
}

// MARK: - Внутренняя однофайловая реализация снимка экрана

private enum Snapshot {
    enum Error: Swift.Error {
        case noDisplays
        case timeout
        case cancelled
        case internalFailure(String)
    }

    static func captureAllDisplaysPNG(maxSide: CGFloat = 1280) async throws -> Data {
        let cg = try await captureAllDisplaysCGImage(width: 1280, height: 720, showsCursor: false, timeout: 2.0)
        let resized = resizeCGImage(cg, maxSide: maxSide)
        return pngData(from: resized)
    }

    static func captureAllDisplaysCGImage(
        width: Int = 1280,
        height: Int = 720,
        showsCursor: Bool = false,
        timeout: TimeInterval = 2.0
    ) async throws -> CGImage {

        let content = try await SCShareableContent.excludingDesktopWindows(false, onScreenWindowsOnly: true)
        guard let main = content.displays.first else { throw Error.noDisplays }

        let filter = SCContentFilter(display: main, excludingWindows: [])

        let cfg = SCStreamConfiguration()
        cfg.width  = (width  / 8) * 8
        cfg.height = (height / 8) * 8
        cfg.showsCursor = showsCursor
        cfg.pixelFormat = kCVPixelFormatType_32BGRA

        let grabber = SingleFrameGrabber(queueLabel: "sc.single.grab.queue")
        return try await grabber.grab(filter: filter, configuration: cfg, timeout: timeout)
    }

    private static func pngData(from cg: CGImage) -> Data {
        let data = NSMutableData()
        guard let dest = CGImageDestinationCreateWithData(data, UTType.png.identifier as CFString, 1, nil) else {
            fatalError("CGImageDestinationCreateWithData failed")
        }
        CGImageDestinationAddImage(dest, cg, nil)
        CGImageDestinationFinalize(dest)
        return data as Data
    }

    private static func resizeCGImage(_ src: CGImage, maxSide: CGFloat) -> CGImage {
        let w = CGFloat(src.width), h = CGFloat(src.height)
        let scale = min(1, maxSide / max(w, h))
        let newW = max(1, Int(w * scale))
        let newH = max(1, Int(h * scale))

        let cs = src.colorSpace ?? CGColorSpaceCreateDeviceRGB()
        let ctx = CGContext(
            data: nil,
            width: newW, height: newH,
            bitsPerComponent: 8,
            bytesPerRow: 0,
            space: cs,
            bitmapInfo: CGImageAlphaInfo.premultipliedLast.rawValue
        )!
        ctx.interpolationQuality = .high
        ctx.draw(src, in: CGRect(x: 0, y: 0, width: newW, height: newH))
        return ctx.makeImage()!
    }

    private final class SingleFrameGrabber: NSObject, SCStreamOutput, SCStreamDelegate {
        private var stream: SCStream?
        private var cont: CheckedContinuation<CGImage, Swift.Error>?
        private var finished = false

        private let ci = CIContext()
        private let queue: DispatchQueue

        init(queueLabel: String) {
            self.queue = DispatchQueue(label: queueLabel)
            super.init()
        }

        deinit { stop() }

        func grab(filter: SCContentFilter, configuration: SCStreamConfiguration, timeout: TimeInterval) async throws -> CGImage {
            let stream = SCStream(filter: filter, configuration: configuration, delegate: self)
            self.stream = stream

            try stream.addStreamOutput(self, type: .screen, sampleHandlerQueue: queue)
            try await stream.startCapture()

            return try await withTaskCancellationHandler(operation: {
                try await withCheckedThrowingContinuation { (c: CheckedContinuation<CGImage, Swift.Error>) in
                    self.cont = c
                    self.queue.asyncAfter(deadline: .now() + timeout) { [weak self] in
                        guard let self, !self.finished else { return }
                        self.finish(error: Snapshot.Error.timeout)
                    }
                }
            }, onCancel: { [weak self] in
                self?.finish(error: Snapshot.Error.cancelled)
            })
        }

        private func stop() {
            try? stream?.stopCapture()
            stream = nil
        }

        func stream(_ stream: SCStream, didOutputSampleBuffer sb: CMSampleBuffer, of type: SCStreamOutputType) {
            guard type == .screen, let pb = sb.imageBuffer else { return }
            let ciImage = CIImage(cvPixelBuffer: pb)
            if let cg = ci.createCGImage(ciImage, from: ciImage.extent) {
                finish(image: cg)
            }
        }

        func stream(_ stream: SCStream, didStopWithError error: Swift.Error) {
            finish(error: error)
        }

        private func finish(image: CGImage) {
            queue.async {
                guard !self.finished else { return }
                self.finished = true
                self.stop()
                self.cont?.resume(returning: image)
                self.cont = nil
            }
        }

        private func finish(error: Swift.Error) {
            queue.async {
                guard !self.finished else { return }
                self.finished = true
                self.stop()
                self.cont?.resume(throwing: error)
                self.cont = nil
            }
        }
    }
}

#if os(macOS)
import AppKit
import SwiftUI

public struct WindowChromeTweaks: NSViewRepresentable {
    public init() {}

    public func makeNSView(context: Context) -> NSView {
        let v = NSView()
        v.wantsLayer = true
        v.layer?.backgroundColor = NSColor.clear.cgColor
        DispatchQueue.main.async {
            if let w = v.window {
                w.titleVisibility = .hidden
                w.titlebarAppearsTransparent = true
                w.isMovableByWindowBackground = false
                w.backgroundColor = .clear
            }
        }
        return v
    }

    public func updateNSView(_ nsView: NSView, context: Context) {}
}
#else
public struct WindowChromeTweaks: View {
    public init() {}
    public var body: some View { Color.clear.ignoresSafeArea() }
}
#endif

import Foundation

/// Потокобезопасный буфер последних реплик
final class TranscriptBuffer {
    static let shared = TranscriptBuffer()
    private init() {}

    private struct Item { let t: Date; let text: String }
    private let q = DispatchQueue(label: "TranscriptBuffer.q", qos: .userInitiated)
    private var items: [Item] = []
    private var partial: Item? = nil

    private static let noSpaceCharacters: Set<Character> = [".", "?", "!", ",", ";", ":", "…"]

    func appendFinal(_ text: String, at time: Date = .init()) {
        let clean = text.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !clean.isEmpty else { return }
        q.async {
            self.items.append(.init(t: time, text: clean))
            if self.items.count > 500 { self.items.removeFirst(self.items.count - 500) }
            self.partial = nil
        }
    }

    func mergeIntoLastFinal(_ text: String) {
        let clean = text.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !clean.isEmpty else { return }
        q.async {
            guard let last = self.items.popLast() else { return }
            let merged = TranscriptBuffer.mergeSegments(base: last.text, addition: clean)
            self.items.append(.init(t: Date(), text: merged))
            self.partial = nil
        }
    }

    func replaceLastFinal(with text: String, at time: Date = .init()) {
        let clean = text.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !clean.isEmpty else { return }
        q.async {
            let item = Item(t: time, text: clean)
            if self.items.isEmpty {
                self.items.append(item)
            } else {
                _ = self.items.popLast()
                self.items.append(item)
            }
            if self.items.count > 500 { self.items.removeFirst(self.items.count - 500) }
            self.partial = nil
        }
    }

    func setPartial(_ text: String, at time: Date = .init()) {
        let clean = text.trimmingCharacters(in: .whitespacesAndNewlines)
        q.async {
            self.partial = clean.isEmpty ? nil : .init(t: time, text: clean)
        }
    }

    static func mergeSegments(base: String, addition: String) -> String {
        let trimmedAddition = addition.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmedAddition.isEmpty else { return base }

        var result = base
        if result.isEmpty {
            return trimmedAddition
        }

        if let first = trimmedAddition.first, noSpaceCharacters.contains(first) {
            while let last = result.last, last.isWhitespace {
                result.removeLast()
            }
        } else if let last = result.last, !last.isWhitespace {
            result.append(" ")
        }

        result.append(trimmedAddition)
        return result
    }

    func tail(lastSeconds: Int = 40, maxChars: Int = 900) -> String {
        let now = Date()
        return q.sync {
            let cut = now.addingTimeInterval(TimeInterval(-lastSeconds))
            var chunks = items.filter { $0.t >= cut }.map { $0.text }
            if let p = partial, p.t >= cut { chunks.append(p.text) }
            var s = chunks.joined(separator: " ")
            if s.count > maxChars { s = String(s.suffix(maxChars)) }
            return s.trimmingCharacters(in: .whitespacesAndNewlines)
        }
    }

    func clear() {
        q.async {
            self.items.removeAll(keepingCapacity: false)
            self.partial = nil
        }
    }
}

// === АВТО-РЕСАЙЗ МОДИФИКАТОР ===

private enum OverlaySizeKey: PreferenceKey {
    static var defaultValue: CGSize = .zero
    static func reduce(value: inout CGSize, nextValue: () -> CGSize) { value = nextValue() }
}

private struct OverlayAutoResize: ViewModifier {
    @State private var last: CGSize = .zero
    func body(content: Content) -> some View {
        content
            .fixedSize(horizontal: false, vertical: true)
            .background(
                GeometryReader { proxy in
                    Color.clear.preference(key: OverlaySizeKey.self, value: proxy.size)
                }
            )
         .onPreferenceChange(OverlaySizeKey.self) { new in
             if abs(new.width - last.width) > 0.5 || abs(new.height - last.height) > 0.5 {
                 last = new
                 // Если подавление включено — пропускаем тик
                 if !OverlayWindowManager.shared.isAutoResizeSuppressed {
                     OverlayWindowManager.shared.scheduleResize(animate: false, coalesce: 0.02)
                 }
             }
         }
    }
}

extension View {
    func overlayAutoResize() -> some View { modifier(OverlayAutoResize()) }
}


private struct EdgeFade: ViewModifier {
    var height: CGFloat = 420
    func body(content: Content) -> some View {
        content
            .frame(height: height)
            .mask(
                LinearGradient(
                    stops: [
                        .init(color: .clear, location: 0.0),
                        .init(color: .black,  location: 0.06),
                        .init(color: .black,  location: 0.94),
                        .init(color: .clear, location: 1.0)
                    ],
                    startPoint: .top, endPoint: .bottom
                )
            )
            .clipped()
    }
}
private extension View {
    func edgeFade(height: CGFloat = 420) -> some View {
        modifier(EdgeFade(height: height))
    }
}
private struct Glow: ViewModifier {
    var active: Bool
    var color: Color
    func body(content: Content) -> some View {
        content
            .shadow(color: active ? color.opacity(0.45) : .clear, radius: 4)
            .shadow(color: active ? color.opacity(0.25) : .clear, radius: 8)
    }
}

private extension View {
    func glow(active: Bool, color: Color) -> some View {
        modifier(Glow(active: active, color: color))
    }
}
private struct TranscriptGroup: Identifiable {
    let id = UUID()
    let source: OverlayModel.AudioSourceKind
    let items: [OverlayModel.TranscriptMessage]
}

private func grouped(_ messages: [OverlayModel.TranscriptMessage]) -> [TranscriptGroup] {
    guard !messages.isEmpty else { return [] }
    var result: [TranscriptGroup] = []
    var buf: [OverlayModel.TranscriptMessage] = [messages[0]]
    for m in messages.dropFirst() {
        if m.source == buf.last?.source {
            buf.append(m)
        } else {
            result.append(.init(source: buf[0].source, items: buf))
            buf = [m]
        }
    }
    result.append(.init(source: buf[0].source, items: buf))
    return result
}
